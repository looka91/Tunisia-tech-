import { Environment } from "../app/app.config";


export const environment: Environment = {
    env: 'local',
    production: false,
    apiBaseUrl: 'cors',
    serverBaseUrl: 'http://localhost:8088'
  };