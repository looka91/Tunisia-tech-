import { Environment } from "../app/app.config";

export const environment: Environment = {
    env: 'prod',
    production: true,
    serverBaseUrl: ''  
  };