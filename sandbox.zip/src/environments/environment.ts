import { Environment } from "../app/app.config";

export const environment: Environment = {
    env: '<NONE>',
    production: false,
    serverBaseUrl: '<change-env>'  
  };