import { Environment } from "../app/app.config";

export const environment: Environment = {
    env: 'test',
    production: false,
    serverBaseUrl: 'http://server-moker-tst.os-pxl-tst-sap-service.svc.cluster.local:8080'
  };