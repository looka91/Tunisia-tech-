import { ToasterService } from "../components/toaster/toasterService";

export class ExceptionHandler {
    static handleError(error: any, toaster: ToasterService) {
      console.error(error);
      toaster.error('Error fetching data', { duration: 5000, position: 'top' });
    }
  }