import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { delay, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EndpointServiceService {

  private baseUrl = '/api/client';  // Base URL for the client API

  constructor(private http: HttpClient) { }

  // Fetch the list of endpoints for a given client ID
  getClientsEndpointsSimply(clientId: string): Observable<any[]> {
    // return this.http.get<any[]>(`${this.baseUrl}/${clientId}/simp`);

    return of([
      { id: '1', name: 'Endpoint 1' },
      { id: '2', name: 'Endpoint 2' },
      { id: '3', name: 'Endpoint 3' }
    ]).pipe(delay(3000));
  }
}
