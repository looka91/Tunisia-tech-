import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Application } from '../../model/application.model';
import { getApplicationSetup } from '../../app.config';

@Injectable({
  providedIn: 'root'
})
export class ApplicationServiceService {

   private apiUrl: string = getApplicationSetup().appliedEnvironment.apiBaseUrl!; 
  
     constructor(private http: HttpClient) {}
  
     getApplicationDetails(id: string): Observable<Application> {
      return this.http.get<Application>(`${this.apiUrl}/api/applications/${id}`);
    }
    
    // Send the form data to the backend
    getAllTheApplications(): Observable<any> {
      const url = `${this.apiUrl}/api/applications`;
      console.warn("URL:",url)
      return this.http.get(url);
    }


}
