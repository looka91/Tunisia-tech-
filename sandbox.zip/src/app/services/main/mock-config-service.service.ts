import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { getApplicationSetup } from '../../app.config';

@Injectable({
  providedIn: 'root'
})
export class MockConfigServiceService {

  private apiUrl: string = getApplicationSetup().appliedEnvironment.apiBaseUrl!; 


   constructor(private http: HttpClient) {}

  // Send the form data to the backend
  createMockConfig(formData: any): Observable<any> {
    const url = `${this.apiUrl}/api/mock-configs`;
    return this.http.post(url, formData);
  }
}
