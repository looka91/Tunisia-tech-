import { Component } from '@angular/core';

@Component({
  selector: 'app-endpoint-details',
  standalone: true,
  imports: [],
  templateUrl: './endpoint-details.component.html',
  styleUrl: './endpoint-details.component.css'
})
export class EndpointDetailsComponent {

}
