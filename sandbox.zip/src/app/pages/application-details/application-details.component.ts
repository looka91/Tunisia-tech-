import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApplicationServiceService } from '../../services/main/application-service.service';
import { Application } from '../../model/application.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-application-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './application-details.component.html',
  styleUrl: './application-details.component.css'
})
export class ApplicationDetailsComponent implements OnInit {

  application: Application | null = null;
  loading: boolean = true;
  errorMessage: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private applicationService: ApplicationServiceService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.fetchApplicationDetails(id);
  }

  fetchApplicationDetails(id: string): void {
    this.applicationService.getApplicationDetails(id)
      .subscribe({
        next: (data) => {
          this.application = data;
          this.loading = false;
        },
        error: (err) => {
          this.errorMessage = 'Failed to load application details';
          this.loading = false;
        }
      });
  }

}
