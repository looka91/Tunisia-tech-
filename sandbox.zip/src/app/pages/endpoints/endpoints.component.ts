import { Component } from '@angular/core';

@Component({
  selector: 'app-endpoints',
  standalone: true,
  imports: [],
  templateUrl: './endpoints.component.html',
  styleUrl: './endpoints.component.css'
})
export class EndpointsComponent {

}
