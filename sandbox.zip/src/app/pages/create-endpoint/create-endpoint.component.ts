import { Component } from '@angular/core';

@Component({
  selector: 'app-create-endpoint',
  standalone: true,
  imports: [],
  templateUrl: './create-endpoint.component.html',
  styleUrl: './create-endpoint.component.css'
})
export class CreateEndpointComponent {

}
