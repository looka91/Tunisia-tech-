import { Component } from '@angular/core';

@Component({
  selector: 'app-mock-configs',
  standalone: true,
  imports: [],
  templateUrl: './mock-configs.component.html',
  styleUrl: './mock-configs.component.css'
})
export class MockConfigsComponent {

}
