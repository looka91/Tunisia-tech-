import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MockConfigsComponent } from './mock-configs.component';

describe('MockConfigsComponent', () => {
  let component: MockConfigsComponent;
  let fixture: ComponentFixture<MockConfigsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MockConfigsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MockConfigsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
