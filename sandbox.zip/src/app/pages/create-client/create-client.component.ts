import { Component } from '@angular/core';

@Component({
  selector: 'app-create-client',
  standalone: true,
  imports: [],
  templateUrl: './create-client.component.html',
  styleUrl: './create-client.component.css'
})
export class CreateClientComponent {

}
