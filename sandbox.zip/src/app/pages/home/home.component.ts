import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { IteratorComponent } from '../../components/iterator/iterator.component';
import { ToasterService } from '../../components/toaster/toasterService';
import { DraggableTabsComponentComponent } from "../../components/draggable-tabs-component/draggable-tabs-component.component";
import { KeyboardInputComponent } from '../../components/form/keyboard-input/keyboard-input.component';
import { StarReviewComponent } from '../../components/form/star-review/star-review.component';
import { DateTimePickerComponent } from '../../components/form/date-time-picker/date-time-picker.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, IteratorComponent, DraggableTabsComponentComponent, KeyboardInputComponent, StarReviewComponent, DateTimePickerComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {

  private toaster = inject(ToasterService);
  isEmailValid = true;
  
  items = [
    { title: 'Item 1', description: 'Description 1', image: 'https://placehold.co/600x400' },
    { title: 'Item 2', description: 'Description 2', image: 'https://placehold.co/600x400' },
    { title: 'Item 3', description: 'Description 3', image: 'https://placehold.co/600x400' },
    { title: 'Item 4', description: 'Description 4', image: 'https://placehold.co/600x400' },
    { title: 'Item 5', description: 'Description 5', image: 'https://placehold.co/600x400' },
    { title: 'Item 6', description: 'Description 6', image: 'https://placehold.co/600x400' },
  ];



  showSuccess() {
    this.toaster.success('Operation Successful', {sound: true, attention: true});
  }

  showError() {
    this.toaster.error('An error occurred', { sound: true, });
  }

  showInfo() {
    this.toaster.info('New update available', {sound: true, clickable: 'https://update.com', attention: true });
  }

  showWarning() {
    this.toaster.warn('Low storage space', {sound: true, attention: true });
  }

  notification() {
  this.toaster.notification('You have a new message', {
    mode: 'icon',
    icon: 'bi-chat-left-text',
    sound: true,
    clickable: 'https://example.com/messages',
  });
    }


    onValueChange($event: any){
      console.warn($event.value)
        this.toaster.info($event.value, {sound: true, clickable: 'https://update.com', attention: true });
    }
}
