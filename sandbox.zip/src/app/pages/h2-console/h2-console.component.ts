import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { getApplicationSetup } from '../../app.config';

@Component({
  selector: 'app-h2-console',
  standalone: true,
  imports: [],
  templateUrl: './h2-console.component.html',
  styleUrl: './h2-console.component.css'
})
export class H2ConsoleComponent {

  h2Url: SafeResourceUrl;
  h2Path = '/h2-console';

  constructor(private sanitizer: DomSanitizer) {
    let baseUrl = getApplicationSetup().appliedEnvironment.serverBaseUrl; 
    this.h2Url = this.sanitizer.bypassSecurityTrustResourceUrl(baseUrl + this.h2Path);
  }
}
