import { ComponentFixture, TestBed } from '@angular/core/testing';

import { H2ConsoleComponent } from './h2-console.component';

describe('H2ConsoleComponent', () => {
  let component: H2ConsoleComponent;
  let fixture: ComponentFixture<H2ConsoleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [H2ConsoleComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(H2ConsoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
