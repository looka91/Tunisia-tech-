import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { DataTableComponent } from "../../components/data-table/data-table.component";
import { ApplicationServiceService } from '../../services/main/application-service.service';
import { ToasterComponent } from '../../components/toaster/toaster.component';
import { ExceptionHandler } from '../../services/exceptionUtils';
import { ToasterService } from '../../components/toaster/toasterService';

@Component({
  selector: 'app-applications',
  standalone: true,
  imports: [DataTableComponent],
  templateUrl: './applications.component.html',
  styleUrl: './applications.component.css'
})
export class ApplicationsComponent  implements OnInit{

  constructor(private applicationsService: ApplicationServiceService) {}
  
  private toaster = inject(ToasterService);
  data! : any[];
  options = { displayIdField: false, pageSize: 5, rowRoute: "applications/{id}/details", clickableRow: true }

  ngOnInit(): void {
    this.fetchApplications();
  }


  fetchApplications() {
    this.applicationsService.getAllTheApplications().subscribe({
      next: (data) => {
        this.data = data;
      },
      error: (error) => {
        console.error('Error fetching Applications:', error);
        ExceptionHandler.handleError(error, this.toaster);
      }
    });
  }

  


}
