import { Component } from '@angular/core';

@Component({
  selector: 'app-create-application',
  standalone: true,
  imports: [],
  templateUrl: './create-application.component.html',
  styleUrl: './create-application.component.css'
})
export class CreateApplicationComponent {

}
