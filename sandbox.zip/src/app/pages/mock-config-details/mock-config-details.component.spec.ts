import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MockConfigDetailsComponent } from './mock-config-details.component';

describe('MockConfigDetailsComponent', () => {
  let component: MockConfigDetailsComponent;
  let fixture: ComponentFixture<MockConfigDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MockConfigDetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MockConfigDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
