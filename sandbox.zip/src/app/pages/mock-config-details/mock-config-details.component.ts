import { Component } from '@angular/core';

@Component({
  selector: 'app-mock-config-details',
  standalone: true,
  imports: [],
  templateUrl: './mock-config-details.component.html',
  styleUrl: './mock-config-details.component.css'
})
export class MockConfigDetailsComponent {

}
