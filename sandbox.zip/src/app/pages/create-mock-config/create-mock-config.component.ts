import { Component, OnInit } from '@angular/core';
import { DynamicListComponent } from "../../components/dynamic-list/dynamic-list.component";
import { MockConfigServiceService } from '../../services/main/mock-config-service.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EndpointServiceService } from '../../services/main/endpoint-service.service';

@Component({
  selector: 'app-create-mock-config',
  standalone: true,
  imports: [CommonModule, FormsModule, DynamicListComponent],
  templateUrl: './create-mock-config.component.html',
  styleUrl: './create-mock-config.component.css'
})
export class CreateMockConfigComponent implements OnInit {

  parameters: { key: string, value: string }[] = [];
  headers: { key: string, value: string }[] = [];
  mockResponseBody: string = '';
  mockResponseStatus: string = '200';
  isMockConfigActive: boolean = true;
  endpointId: string = '';  // You may want to get this from your dropdown selection
  endPoints: { id: string, name: string }[] = [];  // List of endpoints (fetched from the backend or hardcoded)
  clientId!: string;

  constructor(private mockConfigService: MockConfigServiceService, private endpointService: EndpointServiceService) {}

  ngOnInit() {
    this.loadEndPoints();
  }
  
  
  // Handle changes in the parameters list
  onParametersChange(updatedParameters: { key: string, value: string }[]) {
    this.parameters = updatedParameters;
  }

  // Handle changes in the headers list
  onHeadersChange(updatedHeaders: { key: string, value: string }[]) {
    this.headers = updatedHeaders;
  }

  // Form submission logic (similar to your existing code)
  submitMockConfig() {
    const formData = {
      parameters: this.parameters,
      mockResponseHeaders: this.headers.map(convertKeyValue),
      endpointId: this.endpointId,
      mockResponseBody: this.mockResponseBody.trim(),
      mockActive: this.isMockConfigActive,
      mockResponseStatus: this.mockResponseStatus.trim()
    };

    console.log('Submitting data:', formData);

    // You would use Angular's HttpClient here to send formData to your backend
    // Send the formData to the backend API via the service
    this.mockConfigService.createMockConfig(formData).subscribe({
      next: (response) => {
        console.log('Mock configuration created successfully:', response);
        // Redirect to the mocks page or handle success response as needed
        location.href = '/mocks'; // Example redirection after success
      },
      error: (error) => {
        console.error('Error creating mock configuration:', error);
        alert(`Failed to create mock configuration: ${error.message || 'Unknown error'}`);
      }
    });
  }

  // Load the endpoints using the service
  loadEndPoints(): void {
    this.endpointService.getClientsEndpointsSimply(this.clientId).subscribe({
      next: (data) => {
        this.endPoints = data;  // Populate the endPoints list
        console.log('Fetched endpoints:', this.endPoints);
      },
      error: (error) => {
        console.error('Error fetching endpoints:', error);
        alert('Failed to fetch endpoints');
      }
    });
  }
}

function convertKeyValue(obj: { key: string, value: string }): { [key: string]: string } {
  return { [obj.key]: obj.value };
}