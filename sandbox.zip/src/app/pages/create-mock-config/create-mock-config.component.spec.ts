import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateMockConfigComponent } from './create-mock-config.component';

describe('CreateMockConfigComponent', () => {
  let component: CreateMockConfigComponent;
  let fixture: ComponentFixture<CreateMockConfigComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CreateMockConfigComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateMockConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
