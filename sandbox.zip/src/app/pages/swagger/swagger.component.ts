import { Component } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { getApplicationSetup } from '../../app.config';

@Component({
  selector: 'app-swagger',
  standalone: true,
  imports: [],
  templateUrl: './swagger.component.html',
  styleUrl: './swagger.component.css'
})
export class SwaggerComponent {

    swaggerUrl: SafeResourceUrl;
    swaggerUiPath = '/swagger-ui';
  
    constructor(private sanitizer: DomSanitizer) {
      let baseUrl = getApplicationSetup().appliedEnvironment.serverBaseUrl; 
      this.swaggerUrl = this.sanitizer.bypassSecurityTrustResourceUrl(baseUrl + this.swaggerUiPath);
    }
}
