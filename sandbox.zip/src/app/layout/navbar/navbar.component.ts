import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { NavbarItem, navbarItems } from '../../app.routes';
import { AppConfig, getApplicationSetup } from '../../app.config';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {


  navbarItems: NavbarItem[] = navbarItems;
  applicationSetup: AppConfig = getApplicationSetup();
}
