import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { NotFoundPageComponent } from './pages/not-found-page/not-found-page.component';

import { ClientsComponent } from './pages/clients/clients.component';
import { ClientDetailsComponent } from './pages/client-details/client-details.component';
import { CreateClientComponent } from './pages/create-client/create-client.component';
import { EndpointsComponent } from './pages/endpoints/endpoints.component';
import { EndpointDetailsComponent } from './pages/endpoint-details/endpoint-details.component';
import { CreateEndpointComponent } from './pages/create-endpoint/create-endpoint.component';
import { MockConfigsComponent } from './pages/mock-configs/mock-configs.component';
import { MockConfigDetailsComponent } from './pages/mock-config-details/mock-config-details.component';
import { CreateMockConfigComponent } from './pages/create-mock-config/create-mock-config.component';
import { ApplicationsComponent } from './pages/applications/applications.component';
import { ApplicationDetailsComponent } from './pages/application-details/application-details.component';
import { CreateApplicationComponent } from './pages/create-application/create-application.component';
import { H2ConsoleComponent } from './pages/h2-console/h2-console.component';
import { SwaggerComponent } from './pages/swagger/swagger.component';

export const routes: Routes = [
    { path: '', component: HomeComponent },

    { path: 'applications', component: ApplicationsComponent, },
    { path: 'applications/:id/details', component: ApplicationDetailsComponent },
    { path: 'applications/create', component: CreateApplicationComponent },

    { path: 'client', component: ClientsComponent },
    { path: 'client/:id/details', component: ClientDetailsComponent },
    { path: 'client/create', component: CreateClientComponent },

    { path: 'endpoints', component: EndpointsComponent },
    { path: 'endpoints/:id/details', component: EndpointDetailsComponent },
    { path: 'endpoints/create', component: CreateEndpointComponent },

    { path: 'mocks', component: MockConfigsComponent },
    { path: 'mocks/:id/details', component: MockConfigDetailsComponent },
    { path: 'mocks/create', component: CreateMockConfigComponent },

    { path: 'db-console', component: H2ConsoleComponent },
    { path: 'swagger', component: SwaggerComponent },


    { path: 'not-found', component: NotFoundPageComponent },
    { path: '**', redirectTo: 'not-found' }  // Catch-all route
];

export const navbarItems: NavbarItem[] = [
    {
        lable: "Applications",
        route: "/applications"
    },
    {
        lable: "Clients",
        route: "/clients"
    },
    {
        lable: "Endpoints",
        route: "/endpoints"
    },
    {
        lable: "Mocks",
        route: "/mocks"
    },
];

export interface NavbarItem {
    lable: string
    route: string
}
