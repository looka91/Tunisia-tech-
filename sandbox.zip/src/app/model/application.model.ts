export interface Application {
    id: string;
    name: string;
    platform: string | null;
    status: string | null;
    description: string | null;
    serverName: string;
    serverAddress: string | null;
    autoMockActive: boolean;
  }