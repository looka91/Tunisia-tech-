import { CommonModule } from '@angular/common';
import { Component, Input, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-data-table',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.css']
})
export class DataTableComponent implements OnInit, OnChanges {
  @Input() data: any[] | null = null; // Accepts null for loading state
  @Input() options: { 
    displayIdField: boolean;
    pageSize: number;
    idKey?: string; // New optional input for the identifier key
    clickableRow?: boolean; // New optional input for row clickable feature
    rowRoute?: string; // Route pattern with placeholder for ID
  } = { displayIdField: true, pageSize: 10 };

  headers: { key: string; label: string }[] = [];
  displayedData: any[] = [];
  currentPage: number = 1;
  totalPages: number = 1;
  isLoading: boolean = true;
  pages: number[] = [];
  identifierKey: string = '';

  constructor(private router: Router) {}

  ngOnInit() {
    this.checkLoadingState();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['data'] || changes['options']) {
      this.checkLoadingState();
    }
  }

  private checkLoadingState() {
    if (this.data) {
      this.isLoading = false;
      this.initializeTable();
    } else {
      this.isLoading = true;
    }
  }

  private initializeTable() {
    if (!this.data || this.data.length === 0) return;

    // Determine the identifier key
    this.identifierKey = this.options.idKey 
      || this.findIdentifierKey() 
      || Object.keys(this.data[0])[0]; // fallback to first field

    this.headers = Object.keys(this.data[0])
      .filter(key => this.options.displayIdField || key.toLowerCase() !== 'id')
      .map(key => ({ key, label: this.formatHeader(key) }));

    this.totalPages = Math.ceil(this.data.length / this.options.pageSize);
    this.pages = Array.from({ length: this.totalPages }, (_, i) => i + 1);
    this.updateDisplayedData();
  }

  private findIdentifierKey(): string | null {
    const possibleKeys = ['id', 'ID', 'Id'];
    for (let key of possibleKeys) {
      if (this.data && this.data[0] && this.data[0].hasOwnProperty(key)) {
        return key;
      }
    }
    return null;
  }

  private formatHeader(key: string): string {
    return key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
  }

  private updateDisplayedData() {
    if (!this.data) return;
    const start = (this.currentPage - 1) * this.options.pageSize;
    this.displayedData = this.data.slice(start, start + this.options.pageSize);
  }

  changePage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.updateDisplayedData();
    }
  }

  onRowClick(row: any) {
    if (this.options.clickableRow && this.options.rowRoute) {
      const route = this.options.rowRoute.replace('{id}', row[this.identifierKey]);
      this.router.navigate([route]);
    }
  }
}
