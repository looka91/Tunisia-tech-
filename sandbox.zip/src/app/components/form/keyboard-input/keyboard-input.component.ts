import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'keyboard-input',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './keyboard-input.component.html',
  styleUrl: './keyboard-input.component.css'
})
export class KeyboardInputComponent {
  @Input() label!: string;
  @Input() placeholder!: string;
  @Input() isValid!: boolean;
  @Input() message!: string;
  @Input() size: string = '';
  
  @Input() inputType: 'number' | 'text' | 'email' | 'password' = 'text';
  @Output() valueChange = new EventEmitter<any>();

  value: any = '';

  // Optional: Customize pattern for specific types like email or number
  get pattern(): string | null {
    if (this.inputType ===  'email') {
      return '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$';  // Email pattern
    }
    return null;  // No pattern for text or number
  }
}