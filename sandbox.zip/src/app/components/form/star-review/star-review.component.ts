import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-star-review',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './star-review.component.html',
  styleUrl: './star-review.component.css'
})
export class StarReviewComponent {
  rating: number = 0; // Default rating
  hoverRating: number = 0; // Rating during hover
  stars: number[] = [1, 2, 3, 4, 5]; // Array representing 5 stars

  // Function to set the rating when a star is clicked
  setRating(star: number): void {
    this.rating = star;
  }

  // Function to set the hovered rating
  setHoverRating(star: number): void {
    this.hoverRating = star;
  }

  // Reset the hover rating when the mouse leaves the stars
  resetHoverRating(): void {
    this.hoverRating = 0;
  }
}
