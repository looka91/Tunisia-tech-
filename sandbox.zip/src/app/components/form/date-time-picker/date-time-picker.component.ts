import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'date-time-picker',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './date-time-picker.component.html',
  styleUrl: './date-time-picker.component.css'
})
export class DateTimePickerComponent implements OnInit {
  @Input() shadow: boolean = true;
  @Input() sundayColor: string = 'text-danger';

  currentMonth: number;
  currentYear: number;
  currentMonthName: string;
  currentDay: number; // This will store the current day of the month
  days: Array<{ date: number, enabled: boolean, isPrevMonth?: boolean, isNextMonth?: boolean }> = [];
  months: string[] = [
    'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'
  ];
  decades: number[] = [];
  years: number[] = [];
  weekdays: string[] = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  isSelectingMonth: boolean = false;
  isSelectingYear: boolean = false;
  isSelectingDecade: boolean = false;
  startDecade: number = 0;

  constructor() {
    const today = new Date();
    this.currentMonth = today.getMonth();
    this.currentYear = today.getFullYear();
    this.currentDay = today.getDate(); // Store the current day
    this.currentMonthName = this.months[this.currentMonth];

    this.generateDecades();
  }

  ngOnInit(): void {
    this.loadDays();
  }

  loadDays() {
    this.isSelectingMonth = false;
    this.isSelectingYear = false;
    this.isSelectingDecade = false;

    const firstDayOfMonth = new Date(this.currentYear, this.currentMonth, 1);
    const lastDayOfMonth = new Date(this.currentYear, this.currentMonth + 1, 0);
    const firstWeekday = firstDayOfMonth.getDay();
    const totalDaysInMonth = lastDayOfMonth.getDate();

    this.days = [];

    const prevMonthLastDay = new Date(this.currentYear, this.currentMonth, 0).getDate();
    for (let i = firstWeekday - 1; i >= 0; i--) {
      this.days.push({ date: prevMonthLastDay - i, enabled: false, isPrevMonth: true });
    }

    for (let i = 1; i <= totalDaysInMonth; i++) {
      this.days.push({ date: i, enabled: true, isPrevMonth: false, isNextMonth: false });
    }

    const remainingDays = 42 - this.days.length;
    for (let i = 1; i <= remainingDays; i++) {
      this.days.push({ date: i, enabled: false, isNextMonth: true });
    }
  }

  previousMonth() {
    if (this.currentMonth > 0) {
      this.currentMonth--;
    } else {
      this.currentMonth = 11;
      this.currentYear--;
    }
    this.currentMonthName = this.months[this.currentMonth];
    this.loadDays();
  }

  nextMonth() {
    if (this.currentMonth < 11) {
      this.currentMonth++;
    } else {
      this.currentMonth = 0;
      this.currentYear++;
    }
    this.currentMonthName = this.months[this.currentMonth];
    this.loadDays();
  }

  toggleMonthSelect() {
    this.isSelectingMonth = !this.isSelectingMonth;
    this.isSelectingYear = false;
    this.isSelectingDecade = false;
  }

  toggleYearSelect() {
    this.isSelectingDecade = !this.isSelectingDecade;
    this.isSelectingMonth = false;
    this.isSelectingYear = false;
    this.generateDecades();
  }

  generateDecades() {
    this.decades = [];
    const startYear = Math.floor(this.currentYear / 10) * 10;
    for (let i = startYear - 50; i <= startYear + 50; i += 10) {
      this.decades.push(i);
    }
  }

  selectDecade(startYear: number) {
    this.isSelectingDecade = false;
    this.isSelectingYear = true;
    this.startDecade = startYear;
    this.generateYears();
  }

  generateYears() {
    this.years = [];
    for (let i = this.startDecade; i < this.startDecade + 10; i++) {
      this.years.push(i);
    }
  }

  selectYear(year: number) {
    this.currentYear = year;
    this.loadDays();
  }

  selectMonth(index: number) {
    this.currentMonth = index;
    this.currentMonthName = this.months[this.currentMonth];
    this.loadDays();
  }

  selectDate(day: any) {
    if (day.enabled) {
      alert(`You selected: ${this.currentMonthName} ${day.date}, ${this.currentYear}`);
    }
  }
}

