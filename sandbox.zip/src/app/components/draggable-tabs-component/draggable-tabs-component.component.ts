import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { CdkDragDrop, DragDropModule, moveItemInArray } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-draggable-tabs',
  standalone: true,
  imports: [CommonModule, DragDropModule],
  templateUrl: './draggable-tabs-component.component.html',
  styleUrl: './draggable-tabs-component.component.css'
})
export class DraggableTabsComponentComponent implements OnInit {
  tabs = [
    { id: 1, title: 'Tab 1', content: 'Content of Tab 1' },
    { id: 2, title: 'Tab 2', content: 'Content of Tab 2' },
    { id: 3, title: 'Tab 3', content: 'Content of Tab 3' },
    { id: 4, title: 'Tab 4', content: 'Content of Tab 4' }
  ];

  constructor() {}

  ngOnInit(): void {}

  onDrop(event: CdkDragDrop<any[]>): void {
    moveItemInArray(this.tabs, event.previousIndex, event.currentIndex);
  }
}

