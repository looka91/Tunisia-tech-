import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DraggableTabsComponentComponent } from './draggable-tabs-component.component';

describe('DraggableTabsComponentComponent', () => {
  let component: DraggableTabsComponentComponent;
  let fixture: ComponentFixture<DraggableTabsComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DraggableTabsComponentComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DraggableTabsComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
