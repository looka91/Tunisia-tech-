import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-dynamic-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dynamic-list.component.html',
  styleUrl: './dynamic-list.component.css'
})
export class DynamicListComponent {

   // The list will hold the dynamic fields (key-value pairs)
   @Input() listTitle: string = ''; // Title for the list (e.g., "Request Parameters", "Headers")
   @Input() listItems: { key: string, value: string }[] = []; // Initial list items (empty by default)
   @Input() buttonLable: string = 'Add'; // Initial button lable ('Add' by default)
   @Output() listChange = new EventEmitter<{ key: string, value: string }[]>(); // Emit changes to parent
 
   // Add a new key-value pair to the list
   addField() {
     this.listItems.push({ key: '', value: '' });
   }
 
   // Remove a key-value pair from the list by index
   removeField(index: number) {
     this.listItems.splice(index, 1);
     this.emitChange();
   }
 
   // Emit the updated list back to the parent component
   emitChange() {
     this.listChange.emit(this.listItems);
   }
}
