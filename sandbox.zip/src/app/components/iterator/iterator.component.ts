import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, computed, ContentChild, ElementRef, EventEmitter, HostListener, inject, Input, OnInit, Output, signal, TemplateRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-iterator',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './iterator.component.html',
  styleUrl: './iterator.component.css'
})
export class IteratorComponent<T> implements OnInit, AfterViewInit {
  @Input() items: T[] = [];
  @Input() pageSize = 5;
  @Input() listingType: 'grid' | 'list' = 'grid';
  @Input() paginationMode: 'infinite' | 'pages' = 'pages';
  @Input() sourceUrl?: string;
  @Input() mode?: 'serverSide' | 'ClientSide' =  this.sourceUrl? 'serverSide' : 'ClientSide';

  @ContentChild('itemTemplateGrid', { static: false }) itemTemplateGrid!: TemplateRef<any>;
  @ContentChild('iteratorTitle', { static: false }) iteratorTitle!: TemplateRef<any>;
  @ContentChild('itemTemplateList', { static: false }) itemTemplateList!: TemplateRef<any>;
  @ViewChild('scrollContainer') scrollContainer!: ElementRef;

  currentPage = signal(1);
  loading = signal(false);
  totalItems = signal<T[]>([]);
  http = inject(HttpClient);

  private lastScrollPosition = 0; // Store the last scroll position

  ngOnInit() {
    if (this.sourceUrl) {
      this.fetchData();
    } else {
      this.totalItems.set(this.items);
    }
  }

  ngAfterViewInit() {
    this.restoreScrollPosition();
  }

  paginatedItems = computed(() => {
    if (this.sourceUrl) {
      return this.totalItems();
    } else {
      const start = (this.currentPage() - 1) * this.pageSize;
      return this.totalItems().slice(start, start + this.pageSize);
    }
  });

  totalPages = computed(() => Math.ceil(this.totalItems().length / this.pageSize));
  pages = computed(() => Array.from({ length: this.totalPages() }, (_, i) => i + 1));

  prevPage() {
    if (this.currentPage() > 1) {
      this.currentPage.set(this.currentPage() - 1);
      if (this.sourceUrl) this.fetchData();
    }
  }

  nextPage() {
    if (this.currentPage() < this.totalPages()) {
      this.currentPage.set(this.currentPage() + 1);
      if (this.sourceUrl) this.fetchData();
    }
  }

  goToPage(page: number) {
    this.currentPage.set(page);
    if (this.sourceUrl) this.fetchData();
  }

  fetchData() {
    if (!this.sourceUrl) return;
    this.loading.set(true);
    this.lastScrollPosition = window.scrollY; // Save scroll position before fetching

    this.http.get<T[]>(`${this.sourceUrl}?page=${this.currentPage()}&pageSize=${this.pageSize}`).subscribe({
      next: (data) => {
        if (this.paginationMode === 'infinite') {
          this.totalItems.set([...this.totalItems(), ...data]); // Append new data
          this.loading.set(false);
          requestAnimationFrame(() => this.restoreScrollPosition()); // Restore scroll position after rendering
        } else {
          this.totalItems.set(data);
          this.loading.set(false);
        }
      },
      error: () => this.loading.set(false),
    });
  }

  @HostListener('window:scroll', [])
  onScroll(): void {
    if (this.paginationMode === 'infinite' && this.isNearBottom() && !this.loading()) {
      this.currentPage.set(this.currentPage() + 1);
      this.fetchData();
    }
  }

  private isNearBottom(): boolean {
    const threshold = 300;
    return window.innerHeight + window.scrollY >= document.body.offsetHeight - threshold;
  }

  private restoreScrollPosition() {
    if (this.lastScrollPosition) {
      window.scrollTo({ top: this.lastScrollPosition, behavior: 'instant' });
    }
  }
}