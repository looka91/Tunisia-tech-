import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { ToasterService } from './toasterService';

@Component({
  selector: 'app-toaster',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './toaster.component.html',
  styleUrl: './toaster.component.css'
})
export class ToasterComponent implements OnInit, OnDestroy {

  upperToasts$ = this.toasterService.upperToasts$;
  lowerToasts$ = this.toasterService.lowerToasts$;
  position: 'top' | 'bottom' = 'bottom';
  showAttention: boolean = false;
  intervalId: any;

  constructor(private toasterService: ToasterService, private cdr: ChangeDetectorRef) {}

  ngOnInit() {
    // Subscribe to the toasts observable
    this.upperToasts$.subscribe((toasts) => {
      if (toasts && toasts.length > 0) {
        this.showAttentionForNewToast();
      }
    });

    this.lowerToasts$.subscribe((toasts) => {
      if (toasts && toasts.length > 0) {
        this.showAttentionForNewToast();
      }
    });

    // Set up a periodic update every 5 seconds
    this.intervalId = setInterval(() => {
      this.cdr.detectChanges(); // Manually trigger change detection
    }, 8000); // Update every 5 seconds
  }

  ngOnDestroy() {
    // Clear the interval to avoid memory leaks
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  private showAttentionForNewToast() {
    this.showAttention = true;
    setTimeout(() => {
      this.showAttention = false;
    }, 1000); // Reset attention after 1 second
  }

  removeToast(toast: any): void {
      this.toasterService['removeToast'](toast);
  }

  // Method to calculate time difference and return a human-readable format
  getTimeAgo(creationTime: Date): string {
    const currentTime = new Date();
    const timeDifference = currentTime.getTime() - creationTime.getTime(); // difference in milliseconds

    const seconds = Math.floor(timeDifference / 1000); // convert to seconds
    const minutes = Math.floor(seconds / 60); // convert to minutes
    const hours = Math.floor(minutes / 60); // convert to hours

    // If the time difference is less than 5 seconds, show "just now"
    if (seconds < 10) {
      return 'just now';
    } 
    // If it's less than 60 seconds, show the number of seconds ago
    else if (seconds < 60) {
      return `${seconds} second${seconds === 1 ? '' : 's'} ago`;
    } 
    // If it's less than 60 minutes, show the number of minutes ago
    else if (minutes < 60) {
      return `${minutes} minute${minutes === 1 ? '' : 's'} ago`;
    } 
    // If it's less than 12 hours, show the number of hours ago
    else if (hours < 12) {
      return `${hours} hour${hours === 1 ? '' : 's'} ago`;
    } 
    // If it's more than 12 hours, show the exact date of creation
    else {
      return this.formatDate(creationTime);
    }
  }

  // Helper method to format the date to a readable format
  formatDate(date: Date): string {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    };
    return date.toLocaleString('en-US', options);
  }
}
