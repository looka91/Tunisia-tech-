import { Injectable } from '@angular/core';
import { BehaviorSubject, timestamp, Timestamp } from 'rxjs';

interface ToastOptions {
  type?: 'success' | 'info' | 'warning' | 'generic' | 'danger' | 'notification';
  textColor?: string;
  duration?: number;
  closable?: boolean;
  clickable?: string | null;
  position?: 'top' | 'bottom';
  mode?: 'image' | 'icon';
  imgUrl?: string;
  icon?: string;
  attention?: boolean;
  sound?: boolean
}

interface Toast {
  fadeOut?: boolean;
  message: string;
  options: ToastOptions;
  creationTime: Date
}

@Injectable({ providedIn: 'root' })
export class ToasterService {
  private lowerToastsSubject = new BehaviorSubject<Toast[]>([]);
  private upperToastsSubject = new BehaviorSubject<Toast[]>([]);
  lowerToasts$ = this.lowerToastsSubject.asObservable();
  upperToasts$ = this.upperToastsSubject.asObservable();

  success(message: string, options?: ToastOptions) {
    this.addToast(message, { ...options, type: 'success' });
  }

  error(message: string, options?: ToastOptions) {
    this.addToast(message, { ...options, type: 'danger' });
  }

  info(message: string, options?: ToastOptions) {
    this.addToast(message, { ...options, type: 'info' });
  }

  warn(message: string, options?: ToastOptions) {
    this.addToast(message, { ...options, type: 'warning' });
  }

  notification(message: string, options?: ToastOptions) {
    this.addToast(message, { ...options, type: 'notification' });
  }

  toast(message: string, options?: ToastOptions) {
    this.addToast(message, options);
  }

  //Add any kind of toast
  private addToast(message: string, options: ToastOptions = {}) {
    // Set default options
    const defaultOptions: ToastOptions = {
      type: 'generic',
      mode: 'icon',
      textColor: 'white',
      duration: 1500,
      closable: false,
      clickable: null,
      position: 'top',
    };

    if (options.type === 'notification' || options.type === 'generic') {
      defaultOptions.position = 'bottom'
      defaultOptions.icon = 'bi-chat-left-text'
      defaultOptions.duration = -1
    }

    // Merge provided options with defaults
    const mergedOptions: ToastOptions = {
      type: options.type ?? defaultOptions.type,
      mode: options.mode ?? defaultOptions.mode,
      textColor: options.textColor ?? defaultOptions.textColor,
      duration: options.duration ?? defaultOptions.duration,
      closable: options.closable ?? defaultOptions.closable,
      clickable: options.clickable ?? defaultOptions.clickable,
      position: options.position ?? defaultOptions.position,
      imgUrl: options.imgUrl ?? defaultOptions.imgUrl,
      icon: options.icon ?? defaultOptions.icon,
      attention: options.attention ?? defaultOptions.attention,
      sound: options.sound ?? defaultOptions.sound,
    };

    // Check if duration is over 30 seconds or indefinate or not set, and adjust closable
    if (mergedOptions.duration && (mergedOptions.duration > 30000 || mergedOptions.duration === -1)) {
      mergedOptions.closable = true;
    }

    // Create the new toast with the merged options
    const newToast: Toast = { message, options: mergedOptions, creationTime: new Date() };

    // Add the new toast to the propper toasts array
    if (mergedOptions.position === 'top') {
      this.upperToastsSubject.next([...this.upperToastsSubject.value, newToast]);
    } else {
      this.lowerToastsSubject.next([...this.lowerToastsSubject.value, newToast]);
    }


    // If a duration is set and not null, schedule removal after that time
    if (mergedOptions.duration && mergedOptions.duration > -1) {
      setTimeout(() => this.removeToast(newToast), mergedOptions.duration);
    }
    if (options.sound) {
      this.playSound(options.type);
    }
  }

  //Remove the toast
  private removeToast(toast: Toast) {
    // Find the toast in the current list
    const upperToasts = this.upperToastsSubject.value
    const lowerToasts = this.lowerToastsSubject.value;


    const index1 = upperToasts.findIndex(t => t === toast);
    const index2 = lowerToasts.findIndex(t => t === toast);

    if (index1 >= 0) {
      const targetToast: any = upperToasts[index1];
      // Set fadeOut to true for the toast to trigger the fade-out effect
      targetToast.fadeOut = true;

      // Update the toastsSubject with the modified list, which now includes the fadeOut flag
      this.upperToastsSubject.next([...this.upperToastsSubject.value]);

      // After the fade-out duration (500ms), remove the toast
      setTimeout(() => {
        this.upperToastsSubject.next(this.upperToastsSubject.value.filter(t => t !== toast));
      }, 500); // Match this with the duration of the fade-out animation (0.5s)

    } else if (index2 >= 0) {
      const targetToast: any = lowerToasts[index2];
      targetToast.fadeOut = true;

      // Update the toastsSubject with the modified list, which now includes the fadeOut flag
      this.lowerToastsSubject.next([...this.lowerToastsSubject.value]);

      // After the fade-out duration (500ms), remove the toast
      setTimeout(() => {
        this.lowerToastsSubject.next(this.lowerToastsSubject.value.filter(t => t !== toast));
      }, 500); // Match this with the duration of the fade-out animation (0.5s)

    }


  }

  // Play sound based on the toast type
  private playSound(type: any) {
    const soundSrc = this.getSoundFile(type);
    if (soundSrc) {
      const audio = new Audio(soundSrc);
      audio.play();
    }
  }

  // Get the appropriate sound file based on toast type
  private getSoundFile(type: string): string | null {
    const soundMap: { [key: string]: string } = {
      success: '/sounds/success.mp3',
      info: '/sounds/notification-pluck-off.mp3',
      warning: '/sounds/warning.mp3',
      primary: '/sounds/primary.mp3',
      danger: '/sounds/alert.mp3',
      notification: '/sounds/notification.mp3'
    };
    return soundMap[type] || null;
  }
}