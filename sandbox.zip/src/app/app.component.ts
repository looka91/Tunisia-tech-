import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from "./layout/navbar/navbar.component";
import { ToasterComponent } from "./components/toaster/toaster.component";
import { CommonModule } from '@angular/common';
import { getApplicationSetup } from './app.config';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NavbarComponent, ToasterComponent, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  applied = getApplicationSetup().appliedEnvironment; 
}
