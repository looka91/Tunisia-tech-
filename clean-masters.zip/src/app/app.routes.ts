import { Routes } from '@angular/router';
import { HomeComponent } from './components/pages/home/home.component';
import { HomeComponent2 } from './components/pages/home2/home.component';
import { AboutComponent } from './components/pages/about/about.component';
import { ContactComponent } from './components/pages/contact/contact.component';
import { CommercialServiceComponent } from './components/pages/commercial-service/commercial-service.component';
import { ResidentialServicesComponent } from './components/pages/residential-services/residential-services.component';
import { SpecialServiceComponent } from './components/pages/special-service/special-service.component';
import { TermsAndConditionsComponent } from './components/pages/terms-and-conditions/terms-and-conditions.component';
import { CondominiumServiceComponent } from './components/pages/condominium-service/condominium-service.component';

export const routes: Routes = [
     { path: '', component: HomeComponent2 },
     { path: 'about', component: AboutComponent },
     { path: 'contact', component: ContactComponent },
     { path: 'commercial-services', component: CommercialServiceComponent },
     { path: 'residential-services', component: ResidentialServicesComponent },
     { path: 'condominum-services', component: CondominiumServiceComponent },
     { path: 'special-services', component: SpecialServiceComponent },
     { path: 'terms-and-conditions', component: TermsAndConditionsComponent }
];
