import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuotaionCompComponent } from './quotaion-comp.component';

describe('QuotaionCompComponent', () => {
  let component: QuotaionCompComponent;
  let fixture: ComponentFixture<QuotaionCompComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QuotaionCompComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuotaionCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
