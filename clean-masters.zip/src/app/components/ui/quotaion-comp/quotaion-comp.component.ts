import { Component } from '@angular/core';

@Component({
  selector: 'app-quotaion-comp',
  standalone: true,
  imports: [],
  templateUrl: './quotaion-comp.component.html',
  styleUrl: './quotaion-comp.component.css'
})
export class QuotaionCompComponent {

}
