import { Component } from '@angular/core';

@Component({
  selector: 'app-commercial-service',
  standalone: true,
  imports: [],
  templateUrl: './commercial-service.component.html',
  styleUrl: './commercial-service.component.css'
})
export class CommercialServiceComponent {

}
