import { Component } from '@angular/core';

@Component({
  selector: 'app-special-service',
  standalone: true,
  imports: [],
  templateUrl: './special-service.component.html',
  styleUrl: './special-service.component.css'
})
export class SpecialServiceComponent {

}
