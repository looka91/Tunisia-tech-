import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CondominiumServiceComponent } from './condominium-service.component';

describe('CondominiumServiceComponent', () => {
  let component: CondominiumServiceComponent;
  let fixture: ComponentFixture<CondominiumServiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CondominiumServiceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CondominiumServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
