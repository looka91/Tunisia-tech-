import { Component } from '@angular/core';

@Component({
  selector: 'app-condominium-service',
  standalone: true,
  imports: [],
  templateUrl: './condominium-service.component.html',
  styleUrl: './condominium-service.component.css'
})
export class CondominiumServiceComponent {

}
