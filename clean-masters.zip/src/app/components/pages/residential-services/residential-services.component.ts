import { Component } from '@angular/core';

@Component({
  selector: 'app-residential-services',
  standalone: true,
  imports: [],
  templateUrl: './residential-services.component.html',
  styleUrl: './residential-services.component.css'
})
export class ResidentialServicesComponent {

}
