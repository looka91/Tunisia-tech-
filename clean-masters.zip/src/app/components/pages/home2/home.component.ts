import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { HeroComponent } from "../../ui/hero/hero.component";

@Component({
  selector: 'app-home-2',
  standalone: true,
  imports: [CommonModule, TranslateModule, HeroComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent2 {

}
