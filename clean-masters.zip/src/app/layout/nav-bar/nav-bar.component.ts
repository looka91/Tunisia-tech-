import { CommonModule } from '@angular/common';
import { Component, AfterViewInit, HostListener, OnDestroy } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { LanguageService } from '../../services/language.service';
import { NavigationEnd, Router } from '@angular/router';
import { filter, Subscription } from 'rxjs';

@Component({
  selector: 'ui-navbar',
  standalone: true,
  imports: [CommonModule, TranslateModule],
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements AfterViewInit, OnDestroy {
  isScrolled = false;
  activeSection: string = 'home';
  activeRoute: string = '/';
  private observer!: IntersectionObserver;
  languages = ['en', 'fr'];
  activeLang = this.languageService.currentLang;
  private routerSub!: Subscription;
  
  constructor(private languageService: LanguageService, private router: Router) {
    this.routerSub = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.activeRoute = event.urlAfterRedirects;
        console.log("activeRoute", this.activeRoute)
      });
  }
  
  @HostListener('window:scroll', [])
  onWindowScroll() {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    this.isScrolled = scrollTop > 5;
  }

  ngAfterViewInit() {
    const options = {
      root: null,
      threshold: 0.7, // section is active when 70% visible
    };

    this.observer = new IntersectionObserver((entries) => {
      // Filter only sections that are intersecting
      const visibleSections = entries.filter(entry => entry.isIntersecting);

      if (visibleSections.length > 0) {
        // Sort by distance from top of viewport
        visibleSections.sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);

        // Set activeSection to the topmost visible section
        this.activeSection = visibleSections[0].target.id;
      }
    }, options);

    document.querySelectorAll('section').forEach((section) => {
      this.observer.observe(section);
    });
  }

  ngOnDestroy() {
    if (this.observer) this.observer.disconnect();
  }

  
  switchLanguage(lang: string) {
    this.languageService.switch(lang);
    this.activeLang = lang; 
  }
}
