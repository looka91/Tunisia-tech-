import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Injectable({ providedIn: 'root' })
export class LanguageService {
  private storageKey = 'selectedLanguage';

  constructor(private translate: TranslateService) {
    const savedLang = localStorage.getItem(this.storageKey) || translate.getDefaultLang() || 'en';
    this.translate.use(savedLang);
  }

  get currentLang() {
    return this.translate.currentLang || this.translate.getDefaultLang();
  }

  switch(lang: string) {
    if (lang !== this.currentLang) {
      this.translate.use(lang);
      localStorage.setItem(this.storageKey, lang);
    }
  }
}
