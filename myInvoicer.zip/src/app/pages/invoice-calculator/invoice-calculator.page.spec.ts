import { ComponentFixture, TestBed } from '@angular/core/testing';
import { InvoiceCalculatorPage } from './invoice-calculator.page';

describe('InvoiceCalculatorPage', () => {
  let component: InvoiceCalculatorPage;
  let fixture: ComponentFixture<InvoiceCalculatorPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceCalculatorPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
