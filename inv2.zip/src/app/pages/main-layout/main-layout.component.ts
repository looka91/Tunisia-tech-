import { CommonModule } from '@angular/common';
import { Component, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { isTranspActivationRoutes } from '../../app.routes';
import { applicationName } from '../../app.config';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './main-layout.component.html',
  styleUrl: './main-layout.component.css'
})
export class MainLayoutComponent {

  navbarOpacity = 0; // Start with fully opaque navbar
  mode: 'scrollPercent' | 'scrollPx' = 'scrollPx'; // Default mode is scrollPercent
  isTranspActivated = false; // Track if the current route is home
  appName = applicationName;
  appLogo = "";
  constructor(private router: Router) {}

  @HostListener('window:scroll', [])
  onWindowScroll(): void {
    if (!this.isTranspActivated) {
      return; // No scrolling effect if not on the home page
      
    }
    this.navbarOpacity = 0
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight;
    const winHeight = window.innerHeight;

    if (this.mode === 'scrollPercent') {
      // Scroll Percentage Mode
      const scrollPercent = Math.min(scrollTop / (docHeight - winHeight), 0.2); // Max out at 20%
      this.navbarOpacity = scrollPercent;
    } else if (this.mode === 'scrollPx') {
      // Scroll Pixel Mode
      const maxScroll = 300; // Define the max pixel scroll where the navbar becomes fully transparent
      const scrollPercentage = Math.min(scrollTop / maxScroll, 1); // Normalized value between 0 and 1
      this.navbarOpacity = scrollPercentage; // Fade out with scroll
    }
  }

  ngOnInit(): void {

    // Listen for route changes to check if we're on the home page
    this.router.events.subscribe(() => {
      this.isTranspActivated = isTranspActivationRoutes.includes(this.router.url) ; // Check if current route is "/"
      this.navbarOpacity = this.isTranspActivated ? 0 : 1
    });
    
    // Initialize navbar opacity on page load
    this.onWindowScroll();
  }

  // Toggle between scrollPercent and scrollPx modes
  toggleMode(): void {
    this.mode = this.mode === 'scrollPercent' ? 'scrollPx' : 'scrollPercent';
    this.onWindowScroll(); // Recalculate opacity based on new mode
  }
  
}
