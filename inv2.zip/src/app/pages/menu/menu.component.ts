import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderService } from '../../services/order-service';
import { MenuOfTheDay, Treats } from '../../models/menu.model';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css'
})
export class MenuComponent {

  today = new Date();
  forthDisplayNumber = 3;
  services: MenuOfTheDay[] = [];

  constructor(private menuService: OrderService) {}

  ngOnInit() {
    this.menuService.getMenus().subscribe(
      (data) => {
        this.services = data;
      },
      (error) => {
        console.error('Error fetching menus:', error);
      }
    );
  }



  getMenuOfTheDay(): MenuOfTheDay {
    return this.services.find(service => 
      service.date.toDateString() === this.today.toDateString()
    ) || {
      id: "noMenu",
      chorba: "noMenu",
      slata1: "noMenu",
      slata2: "noMenu",
      slata3: "noMenu",
      mainCourse: "noMenu",
      treats: Treats.BARQUETTE,
      date: new Date()
    };
  }

  getMenusForCarousel(): MenuOfTheDay[] {
    let subSetOfMenus = this.services
    .filter(service => service.date > this.today)
    .sort((a, b) => a.date.getTime() - b.date.getTime())
    .slice(0, this.forthDisplayNumber);
    subSetOfMenus.unshift(this.getMenuOfTheDay())
    return subSetOfMenus
      
  }
  
}
