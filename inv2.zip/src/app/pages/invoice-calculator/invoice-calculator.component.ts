import { CommonModule } from '@angular/common';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';



@Component({
  selector: 'app-invoice-calculator',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './invoice-calculator.component.html',
  styleUrls: ['./invoice-calculator.component.scss']
})
export class InvoiceCalculatorComponent {
  nbMenus = 1;
  chorba = 0;
  salade = 0;
  brik = 0;
  plat = 0;
  ville = 'Luxembourg-Ville';
  factureHTML = '';

  readonly PRIX_MENU = 25;
  readonly PRIX_CHORBA = 6;
  readonly PRIX_SALADE = 6;
  readonly PRIX_BRIK_TAJINE = 3;
  readonly PRIX_PLAT_PRINCIPAL = 10;

  readonly FRAIS_LIVRAISON_LUXEMBOURG = 3;
  readonly FRAIS_LIVRAISON_LUXEMBOURG_GRATUIT = 0;
  readonly FRAIS_LIVRAISON_ESCH = 3;
  readonly FRAIS_LIVRAISON_ESCH_SANS_MENU = 6;
  @ViewChild('ticket') content!:ElementRef;

  modifierValeur(id: string, delta: number): void {
    if (id === 'nbMenus') {
      this.nbMenus = Math.max(0, this.nbMenus + delta);
    } else if (id === 'chorba') {
      this.chorba = Math.max(0, this.chorba + delta);
    } else if (id === 'salade') {
      this.salade = Math.max(0, this.salade + delta);
    } else if (id === 'brik') {
      this.brik = Math.max(0, this.brik + delta);
    } else if (id === 'plat') {
      this.plat = Math.max(0, this.plat + delta);
    }
  }

  calculerPrixMenus(nbMenus: number) {
    let totalMenus = nbMenus * this.PRIX_MENU;
    let reduction = 0;

    if (nbMenus === 2) reduction = 3;
    else if (nbMenus === 3) reduction = 4;
    else if (nbMenus === 4) reduction = 5;
    else if (nbMenus === 5) reduction = 15;

    return { total: totalMenus - reduction, reduction };
  }

  calculerPrixArticles() {
    let totalArticles = 0;
    const items = [];

    if (this.chorba > 0) {
      totalArticles += this.chorba * this.PRIX_CHORBA;
      items.push({ name: 'Chorba', qty: this.chorba, price: this.PRIX_CHORBA, total: this.chorba * this.PRIX_CHORBA });
    }
    if (this.salade > 0) {
      totalArticles += this.salade * this.PRIX_SALADE;
      items.push({ name: 'Salade', qty: this.salade, price: this.PRIX_SALADE, total: this.salade * this.PRIX_SALADE });
    }
    if (this.brik > 0) {
      totalArticles += this.brik * this.PRIX_BRIK_TAJINE;
      items.push({ name: 'Brik/Tajine', qty: this.brik, price: this.PRIX_BRIK_TAJINE, total: this.brik * this.PRIX_BRIK_TAJINE });
    }
    if (this.plat > 0) {
      totalArticles += this.plat * this.PRIX_PLAT_PRINCIPAL;
      items.push({ name: 'Plat principal', qty: this.plat, price: this.PRIX_PLAT_PRINCIPAL, total: this.plat * this.PRIX_PLAT_PRINCIPAL });
    }

    return { totalArticles, items };
  }

  calculerFraisLivraison(ville: string, nbMenus: number) {
    if (ville === 'Luxembourg-Ville') {
      return nbMenus > 0 ? this.FRAIS_LIVRAISON_LUXEMBOURG_GRATUIT : this.FRAIS_LIVRAISON_LUXEMBOURG;
    } else if (ville === 'Esch-sur-Alzette') {
      return nbMenus > 0 ? this.FRAIS_LIVRAISON_ESCH : this.FRAIS_LIVRAISON_ESCH_SANS_MENU;
    }
    return 0;
  }

  calculerFacture() {
    let total = (this.nbMenus * this.PRIX_MENU) + (this.chorba * this.PRIX_CHORBA) +
                (this.salade * this.PRIX_SALADE) + (this.brik * this.PRIX_BRIK_TAJINE) +
                (this.plat * this.PRIX_PLAT_PRINCIPAL);

    const { total: totalMenus, reduction } = this.calculerPrixMenus(this.nbMenus);
    const { totalArticles, items } = this.calculerPrixArticles();
    const fraisLivraison = this.calculerFraisLivraison(this.ville, this.nbMenus);

    const totalFinal = totalMenus + totalArticles + fraisLivraison;

    let factureHTML = `
      <div class="header">
        <div>NOM RESTAURANT</div>
        <div>Téléphone: ici QR</div>
        <div>ADRESSE:</div>
        <div class="line"></div>
        <div>FACTURE</div>
        <div class="line"></div>
      </div>
      <div class="section">
        <div class="item">
          <span>Menus</span>
          <span class="item-price">${this.PRIX_MENU}€ x ${this.nbMenus} = ${totalMenus}€</span>
        </div>
        <div class="item">
          <span>Réduction sur menus</span>
          <span class="item-price">-${reduction}€</span>
        </div>
      </div>
    `;

    if (items.length > 0) {
      factureHTML += `
      <div class="section">
        <div>Articles à la carte:</div>
        ${items.map(item => `
          <div class="item">
            <span>${item.name}</span>
            <span class="item-price">${item.qty} x ${item.price}€ = ${item.total}€</span>
          </div>
        `).join('')}
        <div class="line"></div>
        <div class="item">
          <span>Livraison (${this.ville})</span>
          <span class="item-price">${fraisLivraison}€</span>
        </div>
      </div>
      `;
    }

    factureHTML += `
      <div class="line"></div>
      <div class="total">
        <span>Total à payer</span>
        <span class="item-price">${totalFinal}€</span>
      </div>
      <div class="line"></div>
      <div class="footer">Merci de votre commande!</div>
    `;

    this.factureHTML = factureHTML;
  }

  imprimerFacture() {
    this.calculerFacture();

    

     const printWindow = window.open('', '', 'height=400,width=600');
    printWindow?.document.write(`<html><head><title>Impression Facture</title><style>/* Ticket Styles */
.ticket {
    font-family: monospace;
    font-size: 14px;
    line-height: 1.4;
    width: 100%;
    box-sizing: border-box;
    margin: 0;
    padding: 10px;
    white-space: nowrap;
}

.overview {
    background-color: #f4f4f4;
    border-radius: 10px;
    border: 1px solid #ddd;
    margin-top: 5px;
    margin-bottom: 5px;
}

.ticket .header,
.ticket .footer {
    text-align: center;
    font-weight: bold;
    margin: 10px 0;
}

.ticket .line {
    border-bottom: 1px dashed #333;
    margin: 5px 0;
}

.ticket .section {
    margin: 10px 0;
}

.ticket .item {
    width: 100%;
    display: flex;
    justify-content: space-between;
    font-size: 14px;
}

.ticket .item-price {
    text-align: right;
    width: 100%;
}

.ticket .total {
    font-weight: bold;
    margin-top: 10px;
}

.ticket .reduction {
    font-style: italic;
    color: red;
    margin-top: 10px;
}
</style></head><body><div id="facture" class="ticket">${this.factureHTML}</div></body></html>`);  
    printWindow?.document.close();
    setTimeout(() => printWindow?.print(), 500);
  }

  generatePdfFileName(): string {
    const now = new Date();
  
    // Extracting components of the timestamp
    const ss = String(now.getSeconds()).padStart(2, '0');  // seconds (ss)
    const mm = String(now.getMinutes()).padStart(2, '0');  // minutes (mm)
    const hh = String(now.getHours()).padStart(2, '0');    // hours (hh)
    const dd = String(now.getDate()).padStart(2, '0');     // day (dd)
    const month = String(now.getMonth() + 1).padStart(2, '0'); // month (mm)
    const yyyy = now.getFullYear();  // year (yyyy)
  
    // Generating the file name
    const fileName = `facture-${yyyy}${month}${dd}-${hh}${mm}${ss}.pdf`;
    
    return fileName;
  }

  
  sauvegarderPDF() {
    this.calculerFacture();
    setTimeout(() => {
      
      this.content.nativeElement.clas
      let DATA: any = this.content.nativeElement;
      html2canvas(DATA).then((canvas) => {
        let fileWidth = 90;
        let fileHeight = (canvas.height * fileWidth) / canvas.width;
        const FILEURI = canvas.toDataURL('image/png', 1.0);
        let PDF = new jsPDF('p', 'mm', 'a4');
        let position = 0;
        PDF.addImage(FILEURI, 'PNG', 0, position, fileWidth, fileHeight);
        PDF.save(`Facture-${this.generatePdfFileName()}-.pdf`);
      });

    }, 500);
  }

}
