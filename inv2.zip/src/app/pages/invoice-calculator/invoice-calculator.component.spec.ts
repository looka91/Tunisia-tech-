import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceCalculatorComponent } from './invoice-calculator.component';

describe('InvoiceCalculatorComponent', () => {
  let component: InvoiceCalculatorComponent;
  let fixture: ComponentFixture<InvoiceCalculatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InvoiceCalculatorComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InvoiceCalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
