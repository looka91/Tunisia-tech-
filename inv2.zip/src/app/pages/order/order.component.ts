import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { OrderService } from '../../services/order-service';
import { MenuOfTheDay, Treats } from '../../models/menu.model';

@Component({
  selector: 'app-order',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './order.component.html',
  styleUrl: './order.component.css'
})
export class OrderComponent implements OnInit  {
  today = new Date();
  forthDisplayNumber = 3;
  services: MenuOfTheDay[] = [];

  constructor(private menuService: OrderService) {}

  ngOnInit() {
    this.menuService.getMenus().subscribe(
      (data) => {
        this.services = data;
      },
      (error) => {
        console.error('Error fetching menus:', error);
      }
    );
  }



  getMenuOfTheDay(): MenuOfTheDay {
    return this.services.find(service => 
      service.date.toDateString() === this.today.toDateString()
    ) || {
      id: "noMenu",
      chorba: "noMenu",
      slata1: "noMenu",
      slata2: "noMenu",
      slata3: "noMenu",
      mainCourse: "noMenu",
      treats: Treats.BARQUETTE,
      date: new Date()
    };
  }

  getMenusForCarousel(): MenuOfTheDay[] {
    let subSetOfMenus = this.services
    .filter(service => service.date > this.today)
    .sort((a, b) => a.date.getTime() - b.date.getTime())
    .slice(0, this.forthDisplayNumber);
    subSetOfMenus.unshift(this.getMenuOfTheDay())
    return subSetOfMenus
      
  }

}