import { Component, Renderer2 } from '@angular/core';
import { NavigationEnd, Router, RouterEvent, RouterOutlet } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { MainLayoutComponent } from './pages/main-layout/main-layout.component';
import { tiledRoutesDark, tiledRoutesLight } from './app.routes';
import { applicationName } from './app.config';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, IonicModule, MainLayoutComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = applicationName;

  constructor(private router: Router, private renderer: Renderer2) {

    
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        if ( tiledRoutesDark.includes(event.url) || tiledRoutesDark.includes(event.urlAfterRedirects)) {
          this.renderer.addClass(document.body, 'tile-dark');
        } else {
          this.renderer.removeClass(document.body, 'tile-dark');
        }

        if ( tiledRoutesLight.includes(event.url) || tiledRoutesLight.includes(event.urlAfterRedirects)) {
          this.renderer.addClass(document.body, 'tile-light');
        } else {
          this.renderer.removeClass(document.body, 'tile-light');
        }
      }
    });
  }
}
