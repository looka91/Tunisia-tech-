export enum Treats {
    BRIK = 'BRIK',
    TAJINE = 'TAJINE',
    BRIK_DANNOUNI = 'BRIK DANNOUNI',
    BARQUETTE = 'BARQUETTE',
  }
  
  export interface MenuOfTheDay {
    chorba: string;
    slata1: string;
    slata2: string;
    slata3: string;
    mainCourse: string;
    treats: Treats;
    date: Date;
    id: string;
  }