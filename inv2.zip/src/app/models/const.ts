import { MenuOfTheDay, Treats } from "./menu.model";

export const menus: MenuOfTheDay[] = [
    {
      id: "00001",
      chorba: "Chorba Hout",
      slata1: "Tounsia",
      slata2: "Mechwiya",
      slata3: "Mfawra",
      mainCourse: "Cousksi",
      treats: Treats.BRIK,
      date: new Date("03-02-2025")
    },
    {
      id: "00002",
      chorba: "Chorba Djej",
      slata1: "Tounsia",
      slata2: "Mechwiya",
      slata3: "Mfawra",
      mainCourse: "Ma9rouna",
      treats: Treats.BRIK,
      date: new Date("03-03-2025")
    },
    {
      id: "00002",
      chorba: "Chorba Hout",
      slata1: "Tounsia",
      slata2: "Mechwiya",
      slata3: "Blankit",
      mainCourse: "loubya bel k3aber",
      treats: Treats.BRIK_DANNOUNI,
      date: new Date("03-04-2025")
    },
    {
      id: "00003",
      chorba: "Chorba Hout",
      slata1: "Tounsia",
      slata2: "Mechwiya",
      slata3: "Mfawra",
      mainCourse: "Cousksi",
      treats: Treats.BRIK,
      date: new Date("03-05-2025")
    },
    {
      id: "00004",
      chorba: "Chorba Djej",
      slata1: "Tounsia",
      slata2: "Mechwiya",
      slata3: "Mfawra",
      mainCourse: "Ma9rouna",
      treats: Treats.BRIK,
      date: new Date("03-06-2025")
    },
    {
      id: "00005",
      chorba: "Chorba Hout",
      slata1: "Tounsia",
      slata2: "Mechwiya",
      slata3: "Blankit",
      mainCourse: "loubya bel k3aber",
      treats: Treats.BRIK_DANNOUNI,
      date: new Date("03-07-2025")
    }
  ];