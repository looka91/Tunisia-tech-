import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { InvoiceCalculatorComponent } from './pages/invoice-calculator/invoice-calculator.component';
import { OrderComponent } from './pages/order/order.component';
import { MenuComponent } from './pages/menu/menu.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { ServerErrorComponent } from './pages/server-error/server-error.component';

export const routes: Routes = [
    { path: '', component: HomeComponent },
    { path: 'invcal', component: InvoiceCalculatorComponent },
    { path: 'menu', component: MenuComponent },
    { path: 'order', component: OrderComponent },

    { path: 'not-found', component: NotFoundComponent },
    { path: '500', component: ServerErrorComponent },
    { path: '**', redirectTo: 'not-found' }  // Catch-all route
];

export const tiledRoutesDark = ['/', '/home', '/not-found', '/menu'];
export const tiledRoutesLight = ['/menu'];

export const isTranspActivationRoutes = ['/', '/not-found'];
