import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MenuOfTheDay } from '../models/menu.model';
import { delay, Observable, of } from 'rxjs';
import { menus } from '../models/const';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  private apiUrl = 'https://api.example.com/menus'; // Replace with your actual API URL

  constructor(private http: HttpClient) {}

  getMenus(): Observable<MenuOfTheDay[]> {
    //return this.http.get<MenuOfTheDay[]>(this.apiUrl);
    return of(menus).pipe(delay(3000)); // Simulate 3-second delay
  }

}
