import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  cards = [
    {
      title: 'Invoice Calculator',
      description: 'Use this feature to calculate your invoice total based on quantity and price.',
      image: 'https://via.placeholder.com/150',
      link: '/invoice-calculator',
    },
    {
      title: 'Card 2',
      description: 'This is a description for Card 2.',
      image: 'https://via.placeholder.com/150',
      link: '#',
    },
    {
      title: 'Card 3',
      description: 'This is a description for Card 3.',
      image: 'https://via.placeholder.com/150',
      link: '#',
    },
    {
      title: 'Card 4',
      description: 'This is a description for Card 4.',
      image: 'https://via.placeholder.com/150',
      link: '#',
    },
    {
      title: 'Card 5',
      description: 'This is a description for Card 5.',
      image: 'https://via.placeholder.com/150',
      link: '#',
    },
    {
      title: 'Card 6',
      description: 'This is a description for Card 6.',
      image: 'https://via.placeholder.com/150',
      link: '#',
    }
  ];

  constructor() {}


}
