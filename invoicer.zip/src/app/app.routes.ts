import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { InvoiceCalculatorComponent } from './invoice-calculator/invoice-calculator.component';

export const routes: Routes = [
    { path: '', component: HomeComponent },
    { path: 'invoice-calculator', component: InvoiceCalculatorComponent },
];
